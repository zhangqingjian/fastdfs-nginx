P=linux64 C=-fPIC L="-s -static-libgcc" D=limage.so A=limage.a ./build.sh
