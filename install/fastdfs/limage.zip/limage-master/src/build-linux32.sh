P=linux32 L="-s -static-libgcc" D=limage.so A=limage.a ./build.sh
